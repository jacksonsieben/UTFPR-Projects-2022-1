#ifndef STRUCT_ARVORE_BINARIA_H
#define STRUCT_ARVORE_BINARIA_H

struct nohArvore{
   void       *info;
   pNohArvore  esquerda;
   pNohArvore  direita;
};

#endif
