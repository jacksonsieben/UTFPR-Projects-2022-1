pDLista teste1 (pDGrafo grafo, pVertice vertice){
    return buscarVerticesIncidentes(grafo, vertice, grafo->fc);
}