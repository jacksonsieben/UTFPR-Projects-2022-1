#include "../Grafos/Grafo.h"
#include "../Arvores/ArvoreBinaria.h"
#include "Utils.h"

/* Adicionar as bibliotecas que voce implementar */ 

#include "Exercicios/0_teste.h"

#include "Exercicios/1_deadEnd.h"
#include "Exercicios/2_ehPerfeita.h"

#include "Exercicios/3_subGrafo.h"
#include "Exercicios/4_regular.h"