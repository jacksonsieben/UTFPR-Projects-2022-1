#ifndef STRUCT_ARVORE_H
#define STRUCT_ARVORE_H

struct nohArvore{
   void       *info;
   pNohArvore  esquerda;
   pNohArvore  direita;
};

#endif
